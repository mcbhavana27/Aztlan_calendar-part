package com.example.calendar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
